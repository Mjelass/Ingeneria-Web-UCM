package es.ucm.fdi.iw.plantilla;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlantillaApplicationTests {

	@Test
	void contextLoads() {
	}

}
